package com.pochi.os

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val req = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(WifiBridge(this@MainActivity), "PochiAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        requestWifiPermissions()
    }

    private fun requestWifiPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        if (Build.VERSION.SDK_INT >= 23) p += Manifest.permission.ACCESS_FINE_LOCATION
        if (p.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, p.toTypedArray(), req)
        }
    }

    inner class WifiBridge(private val ctx: Context) {
        @JavascriptInterface fun getWifiInfo(): String {
            val out = JSONObject()
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val info = wm.connectionInfo
                val dhcp = wm.dhcpInfo
                val net = cm.activeNetwork
                val caps = cm.getNetworkCapabilities(net)
                val lp = if (net != null) cm.getLinkProperties(net) else null
                val connectedWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                out.put("connected", connectedWifi)
                out.put("ssid", cleanSsid(info.ssid))
                out.put("bssid", info.bssid ?: "")
                out.put("mac", info.macAddress ?: "")
                out.put("ip", intToIp(info.ipAddress))
                out.put("gateway", intToIp(dhcp.gateway))
                out.put("dns1", intToIp(dhcp.dns1))
                out.put("dns2", intToIp(dhcp.dns2))
                out.put("netmask", intToIp(dhcp.netmask))
                out.put("frequencyMHz", if (Build.VERSION.SDK_INT >= 21) info.frequency else 0)
                out.put("band", bandName(info))
                out.put("linkSpeedMbps", if (Build.VERSION.SDK_INT >= 21) info.linkSpeed else 0)
                if (Build.VERSION.SDK_INT >= 30) {
                    out.put("txMbps", info.txLinkSpeedMbps)
                    out.put("rxMbps", info.rxLinkSpeedMbps)
                }
                out.put("rssi", info.rssi)
                out.put("signal", signalLabel(info.rssi))
                out.put("wifiStandard", if (Build.VERSION.SDK_INT >= 30) standardName(info.wifiStandard) else "No disponible")
                out.put("security", securityGuess(ctx, info))
                out.put("ipv6", findIpv6(lp))
                out.put("permissionLocation", ActivityCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                out.put("permissionNearby", Build.VERSION.SDK_INT < 33 || ActivityCompat.checkSelfPermission(ctx, Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED)
            } catch (e: Exception) { out.put("error", e.message ?: "No disponible") }
            return out.toString()
        }

        @JavascriptInterface fun openRouter(ip: String) {
            openRouterInternal(ip, false)
        }
        @JavascriptInterface fun openRouterInsidePochi(ip: String) {
            openRouterInternal(ip, true)
        }
        @JavascriptInterface fun openWifiSettings() { ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }

        private fun openRouterInternal(ip: String, inside: Boolean) {
            val clean = ip.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
            if (clean.isBlank()) return
            val url = "http://$clean"
            if (inside) {
                ctx.startActivity(Intent(ctx, RouterActivity::class.java).putExtra("url", url))
            } else {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
            }
        }

        private fun cleanSsid(s: String?): String = when {
            s == null -> ""
            s == "<unknown ssid>" -> ""
            else -> s.trim('"')
        }
        private fun intToIp(v: Int): String = if (v == 0) "" else "${v and 255}.${v shr 8 and 255}.${v shr 16 and 255}.${v shr 24 and 255}"
        private fun bandName(i: WifiInfo): String = when { i.frequency in 2400..2500 -> "2,4 GHz"; i.frequency in 4900..5900 -> "5 GHz"; i.frequency in 5925..7125 -> "6 GHz"; else -> "No disponible" }
        private fun signalLabel(rssi: Int): String = when { rssi >= -55 -> "Excelente"; rssi >= -67 -> "Buena"; rssi >= -75 -> "Aceptable"; rssi == -127 -> "No disponible"; else -> "Débil" }
        private fun standardName(s: Int): String = when (s) { 1 -> "802.11a"; 2 -> "802.11b"; 3 -> "802.11g"; 4 -> "802.11n (Wi‑Fi 4)"; 5 -> "802.11ac (Wi‑Fi 5)"; 6 -> "802.11ax (Wi‑Fi 6)"; 7 -> "802.11ad"; 8 -> "802.11be (Wi‑Fi 7)"; else -> "No disponible" }
        private fun findIpv6(lp: LinkProperties?): String {
            val a = lp?.linkAddresses?.map { it.address }?.firstOrNull { it is Inet6Address && !it.isLoopbackAddress } ?: return ""
            return a.hostAddress ?: ""
        }
        private fun securityGuess(ctx: Context, info: WifiInfo): String {
            // Android does not expose the saved network's WPA mode consistently to third-party apps.
            // Return an honest best-effort value instead of pretending certainty.
            return "Protección no disponible desde Android"
        }
    }
}
